// SPDX-License-Identifier: GPL-2.0-only OR MIT
/*

Copyright (C) 2023 The Falco Authors.

This file is dual licensed under either the MIT or GPL 2. See MIT.txt
or GPL2.txt for full copies of the license.

*/
#pragma once

/* taken from driver/API_VERSION */
#define PPM_API_CURRENT_VERSION_MAJOR 11
#define PPM_API_CURRENT_VERSION_MINOR 0
#define PPM_API_CURRENT_VERSION_PATCH 1

/* taken from driver/SCHEMA_VERSION */
#define PPM_SCHEMA_CURRENT_VERSION_MAJOR 4
#define PPM_SCHEMA_CURRENT_VERSION_MINOR 5
#define PPM_SCHEMA_CURRENT_VERSION_PATCH 2

#include "ppm_api_version.h"

#define DRIVER_VERSION "11.0.1+driver"

#define DRIVER_NAME "falco"

#define DRIVER_DEVICE_NAME "falco"

#define DRIVER_COMMIT "7625e203c17c88c91fa1b1b8e2937907f22a1523"

#ifndef KBUILD_MODNAME
#define KBUILD_MODNAME DRIVER_NAME
#endif
